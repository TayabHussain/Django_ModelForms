from django.db import models

class Reservation(models.Model):

    first_name = models.CharField(default=None, max_length=30)
    last_name = models.CharField(default=None, max_length=30)
    email = models.EmailField(default=None)
    phone = models.IntegerField(default=0)
    adults = models.IntegerField(default=0)
    child = models.IntegerField(default=0)
    street_name = models.CharField(default=None, max_length=300)
    building_no = models.IntegerField(default=0)
    postal_code = models.CharField(default=None, max_length=6)
    city = models.CharField(default=None, max_length=50)
    arrive_date = models.DateField(default=None)
    departure_date = models.DateField(default=None)
    preferred_block = models.CharField(default=None, max_length=50, choices=[('A', 'A'), ('B', 'B'), ('C', 'C'), ('none', 'Geen Voorkeur')])
    camping_equipment = models.CharField(default=None, max_length=20, choices=[('caravan', 'Caravan'), ('tent', 'Tent'), ('bungalow', 'Bungalow')])
    comments = models.TextField(default=None)

    def __str__(self):
        return f"{self.first_name} {self.last_name}'s Reservation"