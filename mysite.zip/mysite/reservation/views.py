from django.shortcuts import render
from django.http import HttpResponse
from .forms import ReservationForm
from .models import Reservation

def index(request):
    form =  ReservationForm()
    context = {'form' :form}
    return render(request, 'reservation.html', context)

def confirm(request):
    form = ReservationForm(request.POST)
    if form.is_valid():
        if request.method == "POST":
            form.save()
    context = {'reservation':Reservation.objects.last()}    
    return render(request, 'confirmation.html', context)

def home(request):
    return render(request, 'home.html')

# Create your views here.
